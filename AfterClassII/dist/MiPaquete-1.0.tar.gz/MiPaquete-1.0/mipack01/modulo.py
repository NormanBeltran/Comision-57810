def calcular_iva(neto): # Devuelve el bruto
    return neto*1.21

provincias = ["Cordoba", "San Juan", "Misiones", "Corrientes", "Neuquen"]
from setuptools import setup

setup(
    name = "MiPaquete",
    version = "1.0",
    description = "Este paquete tiene funciones para calculo IVA y Provincias",
    author = "Norman Beltran",
    author_email = "nb@gmail.com",
    packages=["mipack01"]
)